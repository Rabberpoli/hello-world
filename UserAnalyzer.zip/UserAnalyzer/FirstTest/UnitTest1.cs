using System;
using Xunit;

namespace FirstTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
