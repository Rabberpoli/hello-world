using System;
using Xunit;
using Newtonsoft;
using UserAnalyzer;


namespace XUnitTestUser
{
    public class UnitTest1
    {


        [Fact]
        public void Test1()
        {
            JsonDeserializer jsonDeserializer = new JsonDeserializer();
            jsonDeserializer.JsonToString();
            Assert.True(jsonDeserializer.isFileEmpty());

        }
    }
}
