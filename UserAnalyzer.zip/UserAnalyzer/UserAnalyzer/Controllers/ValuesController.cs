﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace UserAnalyzer.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        static JsonDeserializer jsonDeserializer = new JsonDeserializer();
        static User user = new User();
        // GET api/values
        [HttpGet]
        public string Get()
        {
            jsonDeserializer.JsonToString();
            user = JsonConvert.DeserializeObject<User>(jsonDeserializer.json);
            string userAttributes = user.name + "\n" + user.surname + "\n" + user.id + "\n" + user.student + "\n" + user.stagist + "\n";
            foreach(var hobby in user.hobbies)
            {
               userAttributes = userAttributes + hobby + "\n";
            }
            foreach(var programming_language in user.programming_languages)
            {
                userAttributes = userAttributes + programming_language + "\n";
            }

            return userAttributes;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            jsonDeserializer.JsonToString();
            user = JsonConvert.DeserializeObject<User>(jsonDeserializer.json);
            switch (id)
            {
                case 0:
                    return user.name;
                case 1:
                    return user.surname;
                case 2:
                    return Convert.ToString(user.id);
                case 3:
                    return Convert.ToString(user.student);
                case 4:
                    return Convert.ToString(user.stagist);
                case 5:
                    string userAttributesHobby = "";
                    foreach (var hobby in user.hobbies)
                    {
                         userAttributesHobby = userAttributesHobby + hobby + "\n";
                    }
                    
                    return userAttributesHobby;

                case 6:
                    string userAttributesProg = "";
                    foreach (var programming_language in user.programming_languages)
                    {
                        userAttributesProg = userAttributesProg + programming_language + "\n";
                    }
                    return userAttributesProg;
                default:
                    return "no parameters";
            }
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] User user)
        {
            string json = JsonConvert.SerializeObject(user);
            jsonDeserializer.JsonToFile(json);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromQuery] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

    }

    
}


