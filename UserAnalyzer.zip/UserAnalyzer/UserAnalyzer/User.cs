﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAnalyzer
{
    public class User
    {
        public string name { get; set; }
        public string surname { get; set; }
        public int id { get; set; }
        public bool student { get; set; }
        public bool stagist { get; set; }
        public List<string> hobbies { get; set; }
        public List<string> programming_languages { get; set; }
    }


}
