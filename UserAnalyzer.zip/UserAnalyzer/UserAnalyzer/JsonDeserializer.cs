﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace UserAnalyzer
{
    public class JsonDeserializer
    {
        public string json { get; set; }
        public bool success { get; set; }
        public void JsonToString()
        {
            json = File.ReadAllText(@"c:\users\ruber\source\repos\UserAnalyzer\UserAnalyzer\userFile.json");
            
        }

        public void JsonToFile(string json)
        {
            File.WriteAllText(@"c:\users\ruber\source\repos\UserAnalyzer\UserAnalyzer\userFile1.json", json);
            
        }

        public bool isFileEmpty()
        {
            if (json.Equals(""))
                return true;
            else
                return false;
        }
    }
}
